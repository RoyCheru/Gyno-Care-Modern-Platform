"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="bg-[#f9a8c9] py-4 px-6 md:px-12 lg:px-20">
      <div className="flex items-center justify-between">
        <Link href="/" className="text-2xl font-bold text-foreground">
          Gynocare
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          <Link href="#" className="text-foreground hover:text-[#c94d8a] transition-colors">
            Home
          </Link>
          <Link href="#services" className="text-foreground hover:text-[#c94d8a] transition-colors">
            Services
          </Link>
          <Link href="#how-it-works" className="text-foreground hover:text-[#c94d8a] transition-colors">
            How It Works
          </Link>
          <Link href="#" className="text-foreground hover:text-[#c94d8a] transition-colors">
            About
          </Link>
          <Link href="#" className="text-foreground hover:text-[#c94d8a] transition-colors">
            Contact
          </Link>
        </div>

        <div className="hidden md:flex items-center gap-4">
          <Button variant="ghost" className="text-foreground hover:text-[#c94d8a]">
            Login
          </Button>
          <Button className="bg-[#c94d8a] hover:bg-[#b03d78] text-white rounded-full px-6">Sign Up</Button>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-foreground" onClick={() => setIsOpen(!isOpen)} aria-label="Toggle menu">
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden mt-4 flex flex-col gap-4 pb-4">
          <Link href="#" className="text-foreground hover:text-[#c94d8a] transition-colors">
            Home
          </Link>
          <Link href="#services" className="text-foreground hover:text-[#c94d8a] transition-colors">
            Services
          </Link>
          <Link href="#how-it-works" className="text-foreground hover:text-[#c94d8a] transition-colors">
            How It Works
          </Link>
          <Link href="#" className="text-foreground hover:text-[#c94d8a] transition-colors">
            About
          </Link>
          <Link href="#" className="text-foreground hover:text-[#c94d8a] transition-colors">
            Contact
          </Link>
          <div className="flex flex-col gap-2 mt-2">
            <Button variant="ghost" className="text-foreground justify-start">
              Login
            </Button>
            <Button className="bg-[#c94d8a] hover:bg-[#b03d78] text-white rounded-full">Sign Up</Button>
          </div>
        </div>
      )}
    </nav>
  )
}
